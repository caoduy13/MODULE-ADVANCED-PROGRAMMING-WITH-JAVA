## Contact Manager (Java Console)

Ứng dụng dòng lệnh quản lý danh bạ phục vụ đề thi *Advanced Programming with Java*.

### Chức năng chính
- Quản lý danh bạ trong bộ nhớ: xem theo trang (5 mục/lần), thêm mới, cập nhật, xóa.
- Tìm kiếm gần đúng theo số điện thoại hoặc họ tên.
- Đọc/ghi toàn bộ danh bạ từ/đến tệp CSV (`data/contacts.csv`) với cảnh báo xác nhận.
- Kiểm tra dữ liệu đầu vào (bắt buộc, định dạng số điện thoại, định dạng email).

### Cấu trúc dự án
```
.
├─ README.md
├─ data
│  └─ contacts.csv           # Tệp dữ liệu mẫu
└─ src
   └─ main
      └─ java
         └─ com
            └─ example
               └─ contacts  # Mã nguồn Java
```

### Cách chạy chương trình
1. Mở PowerShell và chuyển vào thư mục dự án `d:\Download\nop28`.
2. Biên dịch:
   ```
   javac -d out src/main/java/com/example/contacts/*.java
   ```
3. Chạy ứng dụng:
   ```
   java -cp out com.example.contacts.ContactApplication
   ```
4. Thực hiện các lựa chọn trên menu được hiển thị.

> Lưu ý: Thư mục `data` phải tồn tại cùng cấp với thư mục `src` để đọc/ghi CSV theo đường dẫn mặc định.

