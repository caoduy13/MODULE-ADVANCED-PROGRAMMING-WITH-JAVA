package com.example.contacts;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public final class ContactValidator {
    private static final Pattern PHONE_PATTERN = Pattern.compile("^0\\d{9,10}$");
    private static final Pattern EMAIL_PATTERN = Pattern.compile("^[\\w._%+-]+@[\\w.-]+\\.[A-Za-z]{2,}$");

    private ContactValidator() {
    }

    public static List<String> validate(Contact contact, boolean validatePhoneFormat) {
        List<String> errors = new ArrayList<>();
        if (contact.getPhoneNumber() == null || contact.getPhoneNumber().isBlank()) {
            errors.add("So dien thoai la bat buoc.");
        } else if (validatePhoneFormat && !PHONE_PATTERN.matcher(contact.getPhoneNumber()).matches()) {
            errors.add("So dien thoai phai gom 10-11 chu so va bat dau bang 0.");
        }

        if (isBlank(contact.getGroupName())) {
            errors.add("Nhom danh ba la bat buoc.");
        }
        if (isBlank(contact.getFullName())) {
            errors.add("Ho ten la bat buoc.");
        }
        if (isBlank(contact.getGender())) {
            errors.add("Gioi tinh la bat buoc.");
        }
        if (isBlank(contact.getAddress())) {
            errors.add("Dia chi la bat buoc.");
        }
        if (isBlank(contact.getBirthDate())) {
            errors.add("Ngay sinh la bat buoc.");
        }
        if (isBlank(contact.getEmail())) {
            errors.add("Email la bat buoc.");
        } else if (!EMAIL_PATTERN.matcher(contact.getEmail()).matches()) {
            errors.add("Email khong dung dinh dang.");
        }
        return errors;
    }

    private static boolean isBlank(String value) {
        return value == null || value.isBlank();
    }
}

