package com.example.contacts;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * Handles reading and writing contacts to CSV files.
 */
public class ContactStorage {
    public static final String[] CSV_HEADERS = {
            "phoneNumber",
            "group",
            "fullName",
            "gender",
            "address",
            "birthDate",
            "email"
    };

    private final Path filePath;

    public ContactStorage(Path filePath) {
        this.filePath = filePath;
    }

    public List<Contact> load() throws IOException {
        List<Contact> contacts = new ArrayList<>();
        if (!Files.exists(filePath)) {
            return contacts;
        }
        try (BufferedReader reader = Files.newBufferedReader(filePath, StandardCharsets.UTF_8)) {
            String header = reader.readLine(); // skip header
            if (header == null) {
                return contacts;
            }
            String line;
            while ((line = reader.readLine()) != null) {
                List<String> columns = splitCsvLine(line);
                if (columns.size() < CSV_HEADERS.length) {
                    continue;
                }
                Contact contact = new Contact(
                        columns.get(0),
                        columns.get(1),
                        columns.get(2),
                        columns.get(3),
                        columns.get(4),
                        columns.get(5),
                        columns.get(6)
                );
                contacts.add(contact);
            }
        }
        return contacts;
    }

    public void save(List<Contact> contacts) throws IOException {
        Files.createDirectories(filePath.getParent());
        try (BufferedWriter writer = Files.newBufferedWriter(filePath, StandardCharsets.UTF_8)) {
            writer.write(String.join(",", CSV_HEADERS));
            writer.newLine();
            for (Contact contact : contacts) {
                writer.write(toCsvRow(contact));
                writer.newLine();
            }
        }
    }

    private String toCsvRow(Contact contact) {
        return String.join(",",
                escape(contact.getPhoneNumber()),
                escape(contact.getGroupName()),
                escape(contact.getFullName()),
                escape(contact.getGender()),
                escape(contact.getAddress()),
                escape(contact.getBirthDate()),
                escape(contact.getEmail())
        );
    }

    private String escape(String value) {
        if (value == null) {
            return "";
        }
        boolean mustQuote = value.contains(",") || value.contains("\"") || value.contains("\n");
        String escaped = value.replace("\"", "\"\"");
        if (mustQuote) {
            return "\"" + escaped + "\"";
        }
        return escaped;
    }

    private List<String> splitCsvLine(String line) {
        List<String> values = new ArrayList<>();
        StringBuilder current = new StringBuilder();
        boolean inQuotes = false;
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (c == '"') {
                if (inQuotes && i + 1 < line.length() && line.charAt(i + 1) == '"') {
                    current.append('"');
                    i++;
                } else {
                    inQuotes = !inQuotes;
                }
            } else if (c == ',' && !inQuotes) {
                values.add(current.toString());
                current.setLength(0);
            } else {
                current.append(c);
            }
        }
        values.add(current.toString());
        return values;
    }
}

