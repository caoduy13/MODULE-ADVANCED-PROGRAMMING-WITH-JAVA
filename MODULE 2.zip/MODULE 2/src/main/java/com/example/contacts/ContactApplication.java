package com.example.contacts;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;

public class ContactApplication {
    private static final Path DEFAULT_DATA_PATH = Paths.get("data", "contacts.csv");

    private final Scanner scanner;
    private final ContactService service;

    public ContactApplication(Scanner scanner, ContactService service) {
        this.scanner = scanner;
        this.service = service;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ContactService service = new ContactService(DEFAULT_DATA_PATH);
        ContactApplication application = new ContactApplication(scanner, service);
        application.run();
    }

    private void run() {
        boolean running = true;
        while (running) {
            printMenu();
            System.out.print("Chon chuc nang: ");
            String choice = scanner.nextLine().trim();
            switch (choice) {
                case "1" -> handleViewContacts();
                case "2" -> handleAddContact();
                case "3" -> handleUpdateContact();
                case "4" -> handleDeleteContact();
                case "5" -> handleSearch();
                case "6" -> handleLoadFromFile();
                case "7" -> handleSaveToFile();
                case "0" -> running = false;
                default -> System.out.println("Lua chon khong hop le, vui long thu lai.");
            }
        }
        System.out.println("Hen gap lai!");
    }

    private void printMenu() {
        System.out.println("\n===== QUAN LY DANH BA =====");
        System.out.println("1. Xem danh sach");
        System.out.println("2. Them moi");
        System.out.println("3. Cap nhat");
        System.out.println("4. Xoa");
        System.out.println("5. Tim kiem");
        System.out.println("6. Doc tu File");
        System.out.println("7. Luu vao File");
        System.out.println("0. Thoat");
    }

    private void handleViewContacts() {
        List<Contact> contacts = service.getContacts();
        if (contacts.isEmpty()) {
            System.out.println("Chua co danh ba nao trong bo nho.");
            return;
        }
        System.out.println("--- DANH SACH DANH BA ---");
        for (int i = 0; i < contacts.size(); i++) {
            Contact contact = contacts.get(i);
            printContact(contact);
            if ((i + 1) % 5 == 0 && i + 1 < contacts.size()) {
                ConsoleUtils.pause(scanner, "Nhan Enter de xem tiep...");
            }
        }
        ConsoleUtils.pause(scanner, "Het danh sach. Nhan Enter de quay lai Menu.");
    }

    private void handleAddContact() {
        System.out.println("--- THEM DANH BA MOI ---");
        String phone = ConsoleUtils.prompt(scanner, "So dien thoai");
        if (service.phoneExists(phone)) {
            System.out.println("So dien thoai da ton tai.");
            return;
        }
        Contact contact = new Contact(
                phone,
                ConsoleUtils.prompt(scanner, "Nhom"),
                ConsoleUtils.prompt(scanner, "Ho ten"),
                ConsoleUtils.prompt(scanner, "Gioi tinh"),
                ConsoleUtils.prompt(scanner, "Dia chi"),
                ConsoleUtils.prompt(scanner, "Ngay sinh (dd/MM/yyyy)"),
                ConsoleUtils.prompt(scanner, "Email")
        );

        List<String> errors = ContactValidator.validate(contact, true);
        if (!errors.isEmpty()) {
            System.out.println("Khong the them danh ba do loi sau:");
            errors.forEach(error -> System.out.println("- " + error));
            return;
        }
        if (service.addContact(contact)) {
            System.out.println("Them danh ba thanh cong.");
        } else {
            System.out.println("Khong the them danh ba (co the so dien thoai da ton tai).");
        }
    }

    private void handleUpdateContact() {
        System.out.println("--- CAP NHAT DANH BA ---");
        while (true) {
            String phone = ConsoleUtils.promptAllowEmpty(scanner, "Nhap so dien thoai can cap nhat");
            if (phone.isBlank()) {
                return;
            }
            Optional<Contact> existing = service.findByPhone(phone);
            if (existing.isEmpty()) {
                System.out.println("Khong tim duoc danh ba voi so dien thoai tren.");
                continue;
            }
            Contact current = existing.get();
                Contact updated = new Contact(
                    phone,
                    ConsoleUtils.promptWithDefault(scanner, "Nhom", current.getGroupName()),
                    ConsoleUtils.promptWithDefault(scanner, "Ho ten", current.getFullName()),
                    ConsoleUtils.promptWithDefault(scanner, "Gioi tinh", current.getGender()),
                    ConsoleUtils.promptWithDefault(scanner, "Dia chi", current.getAddress()),
                    ConsoleUtils.promptWithDefault(scanner, "Ngay sinh (dd/MM/yyyy)", current.getBirthDate()),
                    ConsoleUtils.promptWithDefault(scanner, "Email", current.getEmail())
                );

            List<String> errors = ContactValidator.validate(updated, false);
            if (!errors.isEmpty()) {
                System.out.println("Khong the cap nhat do loi sau:");
                errors.forEach(error -> System.out.println("- " + error));
                continue;
            }
            service.updateContact(phone, updated);
            System.out.println("Cap nhat danh ba thanh cong.");
            return;
        }
    }

    private void handleDeleteContact() {
        System.out.println("--- XOA DANH BA ---");
        while (true) {
            String phone = ConsoleUtils.promptAllowEmpty(scanner, "Nhap so dien thoai can xoa");
            if (phone.isBlank()) {
                return;
            }
            Optional<Contact> existing = service.findByPhone(phone);
            if (existing.isEmpty()) {
                System.out.println("Khong tim duoc danh ba voi so dien thoai tren.");
                continue;
            }
            String confirm = ConsoleUtils.prompt(scanner, "Nhap Y de xac nhan xoa");
            if ("Y".equalsIgnoreCase(confirm)) {
                service.deleteContact(phone);
                System.out.println("Da xoa danh ba.");
            } else {
                System.out.println("Huy xoa danh ba.");
            }
            return;
        }
    }

    private void handleSearch() {
        String keyword = ConsoleUtils.promptAllowEmpty(scanner, "Nhap so dien thoai hoac ho ten can tim");
        if (keyword.isBlank()) {
            System.out.println("Chua nhap tu khoa.");
            return;
        }
        List<Contact> results = service.search(keyword);
        if (results.isEmpty()) {
            System.out.println("Khong tim thay danh ba phu hop.");
        } else {
            System.out.printf("Tim thay %d ket qua:%n", results.size());
            results.forEach(this::printContact);
        }
        ConsoleUtils.pause(scanner, "Nhan Enter de quay lai Menu.");
    }

    private void handleLoadFromFile() {
        String confirm = ConsoleUtils.prompt(scanner,
                "Thao tac se xoa toan bo danh ba dang co trong bo nho. Nhap Y de tiep tuc");
        if (!"Y".equalsIgnoreCase(confirm)) {
            System.out.println("Da huy thao tac.");
            return;
        }
        try {
            service.loadFromFile();
            System.out.println("Da doc du lieu tu file.");
        } catch (IOException e) {
            System.out.println("Khong the doc file: " + e.getMessage());
        }
    }

    private void handleSaveToFile() {
        String confirm = ConsoleUtils.prompt(scanner,
                "Thao tac se ghi de toan bo du lieu trong file. Nhap Y de tiep tuc");
        if (!"Y".equalsIgnoreCase(confirm)) {
            System.out.println("Da huy thao tac.");
            return;
        }
        try {
            service.saveToFile();
            System.out.println("Da luu danh ba vao file.");
        } catch (IOException e) {
            System.out.println("Khong the ghi file: " + e.getMessage());
        }
    }

    private void printContact(Contact contact) {
        System.out.println("----------------------------");
        System.out.println("So dien thoai: " + contact.getPhoneNumber());
        System.out.println("Nhom: " + contact.getGroupName());
        System.out.println("Ho ten: " + contact.getFullName());
        System.out.println("Gioi tinh: " + contact.getGender());
        System.out.println("Dia chi: " + contact.getAddress());
        System.out.println("Ngay sinh: " + contact.getBirthDate());
        System.out.println("Email: " + contact.getEmail());
    }
}

