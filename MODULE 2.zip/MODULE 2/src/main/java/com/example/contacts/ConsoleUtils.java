package com.example.contacts;

import java.util.Scanner;

public final class ConsoleUtils {
    private ConsoleUtils() {
    }

    public static String prompt(Scanner scanner, String message) {
        System.out.print(message + ": ");
        return scanner.nextLine().trim();
    }

    public static String promptAllowEmpty(Scanner scanner, String message) {
        System.out.print(message + " (Enter de bo qua): ");
        return scanner.nextLine().trim();
    }

    public static String promptWithDefault(Scanner scanner, String message, String defaultValue) {
        String suffix = defaultValue == null || defaultValue.isBlank()
                ? ""
                : " [" + defaultValue + "]";
        System.out.print(message + suffix + ": ");
        String input = scanner.nextLine().trim();
        if (input.isBlank()) {
            return defaultValue != null ? defaultValue : "";
        }
        return input;
    }

    public static void pause(Scanner scanner, String message) {
        System.out.println(message);
        scanner.nextLine();
    }
}

