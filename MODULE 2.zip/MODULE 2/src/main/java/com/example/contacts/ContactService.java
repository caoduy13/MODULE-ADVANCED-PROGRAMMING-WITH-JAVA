package com.example.contacts;

import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

public class ContactService {
    private final List<Contact> contacts = new ArrayList<>();
    private final ContactStorage storage;

    public ContactService(Path storagePath) {
        this.storage = new ContactStorage(storagePath);
    }

    public List<Contact> getContacts() {
        return Collections.unmodifiableList(contacts);
    }

    public boolean phoneExists(String phoneNumber) {
        return contacts.stream()
                .anyMatch(contact -> contact.getPhoneNumber().equals(phoneNumber));
    }

    public boolean addContact(Contact contact) {
        if (phoneExists(contact.getPhoneNumber())) {
            return false;
        }
        contacts.add(contact);
        return true;
    }

    public Optional<Contact> findByPhone(String phoneNumber) {
        return contacts.stream()
                .filter(contact -> contact.getPhoneNumber().equals(phoneNumber))
                .findFirst();
    }

    public boolean updateContact(String phoneNumber, Contact updated) {
        Optional<Contact> existing = findByPhone(phoneNumber);
        existing.ifPresent(contact -> {
            contact.setGroupName(updated.getGroupName());
            contact.setFullName(updated.getFullName());
            contact.setGender(updated.getGender());
            contact.setAddress(updated.getAddress());
            contact.setBirthDate(updated.getBirthDate());
            contact.setEmail(updated.getEmail());
        });
        return existing.isPresent();
    }

    public boolean deleteContact(String phoneNumber) {
        return contacts.removeIf(contact -> contact.getPhoneNumber().equals(phoneNumber));
    }

    public List<Contact> search(String keyword) {
        if (keyword == null || keyword.isBlank()) {
            return List.of();
        }
        String lower = keyword.toLowerCase();
        return contacts.stream()
                .filter(contact ->
                        contact.getPhoneNumber().toLowerCase().contains(lower)
                                || contact.getFullName().toLowerCase().contains(lower))
                .toList();
    }

    public void replaceAll(List<Contact> newContacts) {
        contacts.clear();
        contacts.addAll(newContacts);
    }

    public void loadFromFile() throws IOException {
        List<Contact> loaded = storage.load();
        replaceAll(loaded);
    }

    public void saveToFile() throws IOException {
        storage.save(contacts);
    }
}

